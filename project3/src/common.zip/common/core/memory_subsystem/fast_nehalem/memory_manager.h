#ifndef __FAST_NEHALEM_H
#define __FAST_NEHALEM_H

#include "memory_manager_fast.h"

namespace FastNehalem
{
   class CacheBase
   {
      public:
         virtual ~CacheBase() {}
         virtual SubsecondTime access(Core::mem_op_t mem_op_type, IntPtr tag) = 0;
         virtual SubsecondTime tcache_access(Core::mem_op_t mem_op_type, IntPtr tag) = 0;
   };

   class MemoryManager : public MemoryManagerFast
   {
      private:
         CacheBase *icache, *dcache, *l2cache, *tcache;
         static CacheBase *l3cache, *dram;

      public:
         bool use_tcache;
         MemoryManager(Core* core, Network* network, ShmemPerfModel* shmem_perf_model);
         ~MemoryManager();

         SubsecondTime coreInitiateMemoryAccessFast(
               bool use_icache, 
               Core::mem_op_t mem_op_type,
               IntPtr address)
         {
            IntPtr tag = address >> CACHE_LINE_BITS;
	    if (use_icache){
	       SubsecondTime lat_tcache = tcache->tcache_access(mem_op_type, tag);
               if(lat_tcache != SubsecondTime::Zero()){
                 SubsecondTime lat_write_tcache = tcache->access(Core::WRITE, tag); //chamar
                 SubsecondTime lat_icache = icache->access(mem_op_type, tag) * 2;
                 return lat_write_tcache + lat_icache;
               }
               else{
                 return lat_tcache;
               }
	    }
            else{
              return dcache->access(mem_op_type, tag);
            }
            //return (use_icache ? icache : dcache)->access(mem_op_type, tag);

         }
   };
}

#endif // __FAST_NEHALEM_H
