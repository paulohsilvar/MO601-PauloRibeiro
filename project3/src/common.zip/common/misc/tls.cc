#include "tls.h"

TLS::TLS()
{ }

TLS::~TLS()
{ }


