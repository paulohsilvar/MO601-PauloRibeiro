
const char* EStaticNetworkStrings[] = {
   "shmem-1",
   "system",
};


